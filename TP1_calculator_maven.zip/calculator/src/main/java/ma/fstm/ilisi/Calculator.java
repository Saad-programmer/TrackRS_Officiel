package ma.fstm.ilisi;

public class Calculator {

    /** Retourne la somme de deux entiers. */
    public int add(int a, int b) {
        return a + b;
    }

    /** Retourne le produit de deux entiers. */
    public int multiply(int a, int b) {
        return a * b;
    }

}

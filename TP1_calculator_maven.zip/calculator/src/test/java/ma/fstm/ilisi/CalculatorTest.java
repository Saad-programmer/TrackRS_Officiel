package ma.fstm.ilisi;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;

class CalculatorTest {

    private Calculator calculator;

    @BeforeEach
    void setUp() {
        calculator = new Calculator();          // Arrange commun
    }

    @Test
    @DisplayName("0 + 3 = 3")
    void tester() {
        int somme = calculator.add(0, 3);       // Act
        assertEquals(3, somme);                 // Assert
    }

    @ParameterizedTest(name = "{0} + {1} = {2}")
    @CsvSource({ "2, 3, 5", "-4, 3, -1", "7, 0, 7", "-2, -3, -5", "100, 250, 350" })
    void testerAdd(int a, int b, int attendu) {
        assertEquals(attendu, calculator.add(a, b));
    }

    // ===================== multiply (TFD) =====================

    @Test
    @DisplayName("0 x 5 = 0")
    void testerMultiply() {
        int produit = calculator.multiply(0, 5);   // Act
        assertEquals(0, produit);                  // Assert
    }

    @ParameterizedTest(name = "{0} x {1} = {2}")
    @CsvSource({ "2, 3, 6", "-2, 4, -8", "1, 7, 7", "-3, -3, 9", "12, 0, 0" })
    void testerMultiplyParametre(int a, int b, int attendu) {
        assertEquals(attendu, calculator.multiply(a, b));
    }
}
